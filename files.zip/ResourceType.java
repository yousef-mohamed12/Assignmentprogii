package com.marscolony.enums;

public enum ResourceType {
    OXYGEN,
    WATER,
    FOOD,
    FUEL,
    BATTERY_POWER,
    MEDICAL_SUPPLIES,
    SPARE_PARTS
}
